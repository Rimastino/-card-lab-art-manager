# Card_Lab_Art Fidelity Manager

Gestionale clienti, ordini, punti e premi di Card_Lab_Art.

## GitHub Pages
Pubblicare il contenuto della cartella sulla branch `main` e impostare GitHub Pages su:
- Source: Deploy from a branch
- Branch: main
- Folder: / (root)

La pagina principale è `index.html`.
